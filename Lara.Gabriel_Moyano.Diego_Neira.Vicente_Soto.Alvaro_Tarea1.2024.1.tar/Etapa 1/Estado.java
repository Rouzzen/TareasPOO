// LISTA DE ESTADOS DE LA MASCOTA
public enum Estado {
    Neutro,
    Feliz, 
    Triste, 
    Hambriento, 
    Enojado, 
    Cansado,
    Muerto
}
