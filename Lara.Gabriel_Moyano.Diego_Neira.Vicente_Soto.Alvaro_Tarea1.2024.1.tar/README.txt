Vicente Neira 202004663-8
Diego Moyano 202004509-7
Alvaro Soto 202004608-5
Gabriel Lara 202330510-3
--------------------------------------------------
La etapa final cuenta con los siguientes archivos:
Comida.java, Estado.java, Inventario.java, Item.java, Juguete.java, Main.java, Mascota.java, Medicina.java.
config.csv y MAKEFILE.

El primer paso para compilar nuestra tarea es abrir la terminal, luego hay que ocupar el comando cd + el nombre de la carpeta (Etapa 1, Etapa 2, etc) 
y dentro de la carpeta usramos el comando make, luego make run que cumple el rol de ejecutar la tarea y cuando ya hayamos terminado el trabajo, utilizamos make clean.
Para navegar dentro de nuestro programa, se utilizan números para seleccionar lo deseado del menú y para usar los objetos lo hacemos con su ID.

No hicimos la etapa adicional.